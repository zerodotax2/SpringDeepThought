create trigger update_user_counter_insert
  after INSERT
  on PostsUsers
  for each row
  BEGIN
	update UserCounter as u 
    left outer join usernames as un on un.user_counter_id = u.user_counter_id
    SET u.posts = u.posts + '1'
    where un.user_id = NEW.user_id;
END;


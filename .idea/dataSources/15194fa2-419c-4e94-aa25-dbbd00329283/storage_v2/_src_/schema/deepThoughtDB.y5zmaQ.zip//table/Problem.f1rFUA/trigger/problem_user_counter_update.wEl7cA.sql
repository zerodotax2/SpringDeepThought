create trigger problem_user_counter_update
  after UPDATE
  on Problem
  for each row
  BEGIN

	IF OLD.user_id <> NEW.user_id THEN BEGIN 
    
		update UserCounter uc left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
        set uc.problems = uc.problems - '1' where u.user_id = OLD.user_id;
    
		update UserCounter uc left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
        set uc.problems = uc.problems + '1' where u.user_id = NEW.user_id;
    
    END; END IF; 

END;


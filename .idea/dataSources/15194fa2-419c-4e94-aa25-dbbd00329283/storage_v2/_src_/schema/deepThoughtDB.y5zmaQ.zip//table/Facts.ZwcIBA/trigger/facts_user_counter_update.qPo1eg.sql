create trigger facts_user_counter_update
  after UPDATE
  on Facts
  for each row
  BEGIN

	IF OLD.user_id <> NEW.user_id THEN BEGIN 
    
		update UserCounter uc left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
        set uc.facts = uc.facts - '1' where u.user_id = OLD.user_id;
    
		update UserCounter uc left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
        set uc.facts = uc.facts + '1' where u.user_id = NEW.user_id;
    
    END; END IF; 

END;


create trigger user_tag_counter_delete
  after DELETE
  on UsersTags
  for each row
  BEGIN

	update TagCounter as tc 
    left outer join Tags t on t.tag_counter_id = tc.tag_counter_id
    set tc.users = tc.users - '1'
    where t.tag_id = OLD.tag_id;

END;


create trigger article_user_counter_insert
  after INSERT
  on ArticleInfo
  for each row
  BEGIN

	update UserCounter uc 
    left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
    set uc.articles = uc.articles + '1'
	where u.user_id = NEW.user_id;

END;


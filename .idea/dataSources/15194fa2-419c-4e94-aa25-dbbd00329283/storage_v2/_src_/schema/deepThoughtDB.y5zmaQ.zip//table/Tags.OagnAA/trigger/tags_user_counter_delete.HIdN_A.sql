create trigger tags_user_counter_delete
  after DELETE
  on Tags
  for each row
  BEGIN

	update UserCounter uc 
    left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
    set uc.tags = uc.tags - '1'
	where u.user_id = OLD.user_id;

END;


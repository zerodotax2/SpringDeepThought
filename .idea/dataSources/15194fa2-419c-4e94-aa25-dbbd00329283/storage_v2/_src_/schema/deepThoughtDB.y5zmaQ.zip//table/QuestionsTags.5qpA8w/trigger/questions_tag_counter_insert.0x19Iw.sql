create trigger questions_tag_counter_insert
  after INSERT
  on QuestionsTags
  for each row
  BEGIN

	update TagCounter as tc 
    left outer join Tags t on t.tag_counter_id = tc.tag_counter_id
    set tc.questions = tc.questions + '1'
    where t.tag_id = NEW.tag_id;

END;


create trigger articles_user_counter_delete
  after DELETE
  on ArticleInfo
  for each row
  BEGIN

	update UserCounter uc 
    left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
    set uc.articles = uc.articles - '1'
	where u.user_id = OLD.user_id;

END;


create trigger answer_user_counter_delete
  after DELETE
  on Answer
  for each row
  BEGIN

	update UserCounter uc 
    left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
    set uc.answers = uc.answers - '1'
	where u.user_id = OLD.user_id;

END;


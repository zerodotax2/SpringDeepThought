create trigger articles_tag_counter_update
  after UPDATE
  on ArticlesTags
  for each row
  BEGIN

	IF OLD.tag_id <> NEW.tag_id THEN BEGIN
    
		update TagCounter tc left outer join Tags t on t.tag_counter_id = tc.tag_counter_id 
		set tc.articles = tc.articles - '1' where t.tag_id = OLD.tag_id;
		update TagCounter tc left outer join Tags t on t.tag_counter_id = tc.tag_counter_id 
		set tc.articles = tc.articles + '1' where t.tag_id = NEW.tag_id;
        
    END; END IF;

END;


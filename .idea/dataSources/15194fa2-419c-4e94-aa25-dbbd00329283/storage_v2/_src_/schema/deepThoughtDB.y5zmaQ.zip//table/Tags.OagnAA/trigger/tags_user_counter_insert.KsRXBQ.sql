create trigger tags_user_counter_insert
  after INSERT
  on Tags
  for each row
  BEGIN

	update UserCounter uc 
    left outer join UserInfo u on u.user_counter_id = uc.user_counter_id
    set uc.tags = uc.tags + '1'
	where u.user_id = NEW.user_id;
    
END;

